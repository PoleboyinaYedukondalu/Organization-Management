# organization/urls.py
from django.urls import path
from .views import organizations, create_organization, create_employee

urlpatterns = [
    path('', organizations, name='organizations'),  # Add this line for the home view
    path('organizations.html/', organizations, name='organizations'),
    path('create_organization/', create_organization, name='create_organization'),
    path('create_employee/', create_employee, name='create_employee'),
]


