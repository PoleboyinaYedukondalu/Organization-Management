# organization/models.py
from django.db import models

class Organization(models.Model):
    name = models.CharField(max_length=255)
    location = models.CharField(max_length=255)
    industry = models.CharField(max_length=255)

class Employee(models.Model):
    name = models.CharField(max_length=255)
    position = models.CharField(max_length=255)
    organization = models.ForeignKey(Organization, related_name='employees', on_delete=models.CASCADE)

