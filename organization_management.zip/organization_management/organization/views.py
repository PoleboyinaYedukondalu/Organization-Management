# organization/views.py
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
import tkinter as tk
from tkinter import messagebox
from .models import Organization, Employee

def organizations(request):
    organizations_list = Organization.objects.all()
    return render(request, 'organization/organizations.html', {'organizations': organizations_list})

def create_organization(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        location = request.POST.get('location')
        industry = request.POST.get('industry')

        # Input validation for name (text), location (text), and industry (text)
        if not name.isalpha():
            messagebox.showerror("Error", "Name should contain only alphabetic characters.")
            messages.error(request, 'Name should contain only alphabetic characters.')
            return redirect('organizations')

        if not location.isalpha():
            messagebox.showerror("Error", "location should contain only alphabetic characters.")
            messages.error(request, 'Location should contain only alphabetic characters.')
            return redirect('organizations')

        if not industry.isalpha():
            messagebox.showerror("Error", "industry should contain only alphabetic characters.")
            messages.error(request, 'Industry should contain only alphabetic characters.')
            return redirect('organizations')

        organization, created = Organization.objects.get_or_create(name=name, location=location, industry=industry)

        if created:
            messagebox.showinfo("Success", "created successfully!")
            messages.success(request, f'Organization {organization.name} created successfully!')
        else:
            messagebox.showinfo(f"{organization.name}", "already exists!")
            messages.info(request, f'Organization {organization.name} already exists.')

        return redirect('organizations')

    return render(request, 'organization/create_organization.html')

def create_employee(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        position = request.POST.get('position')
        org_name = request.POST.get('org_name')

        # Input validation for name (text), position (text), and org_name (text)
        if not name.isalpha():
            messagebox.showerror("Error", "name should contain only alphabetic characters.")
            messages.error(request, 'Name should contain only alphabetic characters.')
            return redirect('organizations')

        if not position.isalpha():
            messagebox.showerror("Error", "position should contain only alphabetic characters.")
            messages.error(request, 'Position should contain only alphabetic characters.')
            return redirect('organizations')

        if not org_name.isalpha():
            messagebox.showerror("Error", "reganization name should contain only alphabetic characters.")
            messages.error(request, 'Organization Name should contain only alphabetic characters.')
            return redirect('organizations')

        organization = Organization.objects.get(name=org_name)
        employee, created = Employee.objects.get_or_create(name=name, position=position, organization=organization)

        if created:
            messagebox.showinfo("Success", "Employee deatils created successfully!")
            messages.success(request, f'Employee {employee.name} created successfully!')
        else:
            messagebox.showinfo(f"{employee.name}", "already exists!")
            messages.info(request, f'Employee {employee.name} already exists.')

        return redirect('organizations')

    return render(request, 'organization/create_employee.html')
