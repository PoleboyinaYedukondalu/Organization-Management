# organization/views.py
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
from .models import Organization, Employee

def organizations(request):
    organizations_list = Organization.objects.all()
    return render(request, 'organization/organizations.html', {'organizations': organizations_list})

def create_organization(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        location = request.POST.get('location')
        industry = request.POST.get('industry')
        organization, created = Organization.objects.get_or_create(name=name, location=location, industry=industry)

        if created:
            messages.success(request, f'Organization {organization.name} created successfully!')
        else:
            messages.info(request, f'Organization {organization.name} already exists.')

        return redirect('organizations')

    return render(request, 'organization/create_organization.html')

def create_employee(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        position = request.POST.get('position')
        org_name = request.POST.get('org_name')
        organization = Organization.objects.get(name=org_name)
        employee, created = Employee.objects.get_or_create(name=name, position=position, organization=organization)

        if created:
            messages.success(request, f'Employee {employee.name} created successfully!')
        else:
            messages.info(request, f'Employee {employee.name} already exists.')

        return redirect('organizations')

    return render(request, 'organization/create_employee.html')
